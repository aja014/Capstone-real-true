# Validation report

Generated with seed 20260926, today = 2026-10-12. **42 of 42 checks passed.**

## File row counts

| File | Rows |
| --- | --- |
| 1_customer_information | 1133 |
| 2_fire_surveys | 484 |
| 3_motor_quotations | 1480 |
| 4_fire_quotations | 1005 |
| 5_fire_policies | 844 |
| 6_motor_policies | 1174 |
| 7_motor_claims | 344 |
| 8_fire_property_claims | 76 |

## Checks

| Check | Result | Detail |
| --- | --- | --- |
| Headers exactly as the importer expects: 1_customer_information | PASS |  |
| Headers exactly as the importer expects: 2_fire_surveys | PASS |  |
| Headers exactly as the importer expects: 3_motor_quotations | PASS |  |
| Headers exactly as the importer expects: 4_fire_quotations | PASS |  |
| Headers exactly as the importer expects: 5_fire_policies | PASS |  |
| Headers exactly as the importer expects: 6_motor_policies | PASS |  |
| Headers exactly as the importer expects: 7_motor_claims | PASS |  |
| Headers exactly as the importer expects: 8_fire_property_claims | PASS |  |
| No None/NA/N/A/null cell outside Protection Facilities | PASS | [] |
| Survey Occupancy parts add up exactly to Occupancy - Total (= sum insured) | PASS |  |
| Spouse name filled for married clients only | PASS |  |
| Motor policies with a counted loss about 20% (17-24%) | PASS | 20.8% of 850 ended motor policies |
| Fire policies with a counted loss about 9% (7-12%) | PASS | 8.5% of 609 ended fire policies |
| Fraud about 12% of investigated paid claims (10-15%) | PASS | 14.0% (47 of 336) |
| Renewal rate about 70% (62-78%) | PASS | 71.0% |
| CNC share of motor claim rows about 10% (7-16%) | PASS | 9.6% |
| Claims without a label yet about 8% or less | PASS | 4.8% |
| All date rules hold (quote/issue/period, renewals, claim chain, nothing after today) | PASS | [] |
| Renewing Policy No. never points to an unrelated real policy, and is never shared | PASS | [] |
| Policy paperwork filled: invoice and receipt on every policy, receipt numbers unique | PASS |  |
| Policy numbers unique | PASS |  |
| Accuterm numbers unique per accident (third party rows share their accident's number) | PASS |  |
| LOA numbers unique | PASS |  |
| Vehicle plate numbers unique and contain letters | PASS |  |
| Vehicle engine numbers unique and contain letters | PASS |  |
| Vehicle chassis numbers unique and contain letters | PASS |  |
| Every claim points to an existing policy | PASS |  |
| Every policy has its quotation | PASS |  |
| Every renewal points to the same person's earlier policy on the same vehicle/property | PASS |  |
| Importer linking simulation: every policy links to its own quotation | PASS | 0 problems |
| Client full names unique | PASS |  |
| No two clients look alike to the importers (name similarity below 70) | PASS | highest pair = 69.8 |
| Owners with two properties: the two locations are clearly different (below 85) | PASS | highest = 69.0; owners with 2 properties = 26 |
| Every address comes from the verified pool | PASS |  |
| Claim amounts: LOA within estimate, Net = LOA - deductible, all positive | PASS | [] |
| Policy amount equals its quotation amount | PASS |  |
| Final Status always agrees with Claim Investigation Result | PASS | [] |
| Pattern: High-flood motor policies claim more than no-hazard ones | PASS | {'High': (27.0, 259), 'Low': (21.6, 111), 'Medium': (20.3, 236), 'none': (14.3, 244)} |
| Pattern: Commercial vehicles claim more than Private | PASS | {'Commercial': (37.3, 209), 'Private': (15.4, 641)} |
| Pattern: High-flood fire properties claim more than no-hazard ones | PASS | {'High': (13.2, 190), 'Low': (5.6, 107), 'Medium': (7.7, 156), 'none': (5.8, 156)} |
| Pattern: class b buildings claim more than class a | PASS | {'a': (6.3, 397), 'b': (12.7, 212)} |
| Pattern: fraud share rises with red-flag points | PASS | {0: (4.4, 114), 1: (5.6, 90), 2: (3.1, 32), 3: (30.8, 39), 4: (20.0, 25), 5: (40.0, 15), 6: (60.0, 10), 7: (63.6, 11)} |

## Planted patterns (claim rate %, number of ended policies)

- **Motor by flood category:** {'High': (27.0, 259), 'Low': (21.6, 111), 'Medium': (20.3, 236), 'none': (14.3, 244)}
- **Motor by classification:** {'Commercial': (37.3, 209), 'Private': (15.4, 641)}
- **Motor by color (should be flat):** {'Black': (24.4, 164), 'Blue': (20.0, 50), 'Brown': (10.7, 28), 'Gray': (21.8, 119), 'Green': (0.0, 15), 'Orange': (20.0, 15), 'Red': (25.7, 74), 'Silver': (23.0, 152), 'White': (17.6, 233)}
- **Motor renews a policy with a loss:** {False: (19.1, 785), True: (41.5, 65)}
- **Fire by flood category:** {'High': (13.2, 190), 'Low': (5.6, 107), 'Medium': (7.7, 156), 'none': (5.8, 156)}
- **Fire by construction class:** {'a': (6.3, 397), 'b': (12.7, 212)}
- **Fire by protection:** {'not protected': (9.2, 379), 'protected': (7.4, 230)}
- **Fraud share % by red-flag points (points: %, claims):** {0: (4.4, 114), 1: (5.6, 90), 2: (3.1, 32), 3: (30.8, 39), 4: (20.0, 25), 5: (40.0, 15), 6: (60.0, 10), 7: (63.6, 11)}

## Other figures

- Clients 1133, vehicles 747, properties 484
- Motor claim rows 344 (third party rows 34, CNC rows 33), fire claim rows 76
- Final status mix (paid claims): {'Closed Claim': 273, 'Not Push Through': 13, 'Denied Claim': 38, 'With Lacking Docs': 7, 'No Docs. Submitted': 5, 'Waiting for Claim Check': 2, 'Waiting for Billing': 7, 'Waiting for Evaluation': 5, 'Waiting for LOA': 3}
- Labels: {'Legitimate': 289, 'Suspected Fraud': 25, 'Confirmed Fraud': 22, None: 17}
- Fire policy Premium = Total Premium before taxes; Total Amount Due = Premium × 1.27 (DST 12.5%, FST 2%, VAT 12%, LGT 0.5%, from Maagap's real fire policy)