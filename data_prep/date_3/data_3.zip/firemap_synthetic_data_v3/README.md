# FIREMAP synthetic dataset v3 (ends 2026-10-12)

Same generator, rules, seed (20260926) and address pool as v2, with three changes:
1. "Today" is 2026-10-12 (env var G_TODAY), so the data continues through October 12
   (renewals, new business, claims, statuses). Because the simulation runs 16 days longer,
   the random draws differ from v2: a new, equally valid realization, not v2 plus extra rows.
2. Fix (validation P8.10): an invented pre-2023 "Renewing Policy No." can no longer equal a real
   policy number (deterministic re-numbering, no effect on any other value).
3. Fewer empty columns (validation P8.13), filled with their own random sequence so every other value
   is unchanged:
   - Policies (both lines): TIN (the client's, blank when the client has none), Premium Invoice No.,
     Official Receipt No. (chronological across both lines), Replacing Cover Note No. (~35% of new business).
   - Fire policies: Coverage Description (the real form's list: Fire/Lightning, Earthquake, Typhoon, Flood,
     Extended Cover, RSMD) and Premium = Total Premium before taxes; Total Amount Due = Premium × 1.27
     (DST 12.5%, FST 2%, VAT 12%, LGT 0.5%, from Maagap's real fire policy). Changed 2026-10-05: this column
     was "Unit Cost Premium" (a made-up rate per P1,000), which is not on the form.
   - Motor policies: COC No., COI No. (all), Endorsement No. (~6%).
   - Fire quotations: Subjective (all), Mortgagee (~28%).
   Still blank by design: Fire quotation Conditions (no upload column), Endorsement No. on most policies,
   Replacing Cover Note No. on renewals.

Validation: 42 of 42 checks passed (validation_report.md).

Counts: clients 1,133 · fire surveys 484 · motor quotations 1,480 · fire quotations 1,005 ·
fire policies 844 · motor policies 1,174 · motor claims 344 · fire claims 76.
October 1-12: 15 policies issued, 21 quotations, 4 claims reported.

Known and accepted: 339-ish first renewals point to invented 2022 policies (the data starts in 2023);
a few first renewals are issued in late December 2022 for coverage starting in January 2023.

Reproduce:  cd generator && G_TODAY=2026-10-12 python generate.py && G_TODAY=2026-10-12 python validate.py

DO NOT LOAD BEFORE 2026-10-12: it contains records dated up to October 12.
